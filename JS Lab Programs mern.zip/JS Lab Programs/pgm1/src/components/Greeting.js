function Greeting(props){
    return(
        <div>Greeting {props.name}</div>
    )
}

export default Greeting