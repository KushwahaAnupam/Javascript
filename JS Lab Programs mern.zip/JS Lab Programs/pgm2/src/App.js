// import logo from './logo.svg';
import './App.css';
import Registration from './Component/Registration';

function App() {
  return (
    <div className="App">
      <Registration/>
    </div>
  );
}

export default App;
